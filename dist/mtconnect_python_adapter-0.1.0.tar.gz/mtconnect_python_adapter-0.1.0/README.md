# MTconnect Python Adapter

## Description

Python library to map the [MTconnect XML schema]("http://schemas.mtconnect.org/schemas/MTConnectStreams_1.7.xsd") to a python class.